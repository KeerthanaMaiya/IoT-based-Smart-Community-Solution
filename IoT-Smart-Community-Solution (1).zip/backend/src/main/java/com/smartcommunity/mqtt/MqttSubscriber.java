
package com.smartcommunity.mqtt;

import org.eclipse.paho.client.mqttv3.*;

public class MqttSubscriber {
    private final String broker = "tcp://localhost:1883";
    private final String clientId = "JavaClient";
    private final String topic = "smartcommunity/sensordata";

    public void start() throws MqttException {
        MqttClient client = new MqttClient(broker, clientId);
        client.connect();
        client.subscribe(topic, (t, msg) -> {
            String payload = new String(msg.getPayload());
            System.out.println("Received message: " + payload);
            // Store to DB logic here
        });
    }
}
